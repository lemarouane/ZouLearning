<?php
session_start();
require_once '../../includes/db_connect.php';

if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    echo '<option value="">Erreur : Non autorisé</option>';
    exit;
}

$level_id = (int)$_GET['level_id'];
if ($level_id <= 0) {
    echo '<option value="">Choisir une matière</option>';
    exit;
}

$stmt = $db->prepare("SELECT id, name FROM subjects WHERE level_id = ? AND is_archived = 0 ORDER BY name");
$stmt->bind_param("i", $level_id);
$stmt->execute();
$result = $stmt->get_result();

$output = '<option value="">Choisir une matière</option>';
while ($subject = $result->fetch_assoc()) {
    $output .= "<option value='{$subject['id']}'>" . htmlspecialchars($subject['name']) . "</option>";
}
echo $output;
?>