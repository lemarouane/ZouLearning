<?php
session_start();
require_once '../includes/db_connect.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Set timezone for consistency
date_default_timezone_set('Africa/Casablanca');

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submission_id'])) {
    $response = ['success' => false, 'message' => ''];
    $submission_id = (int)$_POST['submission_id'];
    $grade = floatval($_POST['grade']);
    $feedback = trim($_POST['feedback'] ?? '');

    if ($grade < 0 || $grade > 20) {
        $response['message'] = "La note doit être entre 0 et 20.";
        error_log("Invalid grade ($grade) for submission ID $submission_id");
    } else {
        $stmt = $db->prepare("UPDATE quiz_submissions SET grade = ?, feedback = ?, graded_at = NOW() WHERE id = ?");
        $stmt->bind_param("dsi", $grade, $feedback, $submission_id);
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Note et commentaire enregistrés avec succès.";
            $response['grade'] = number_format($grade, 2) . '/20';
            $response['feedback'] = $feedback ? htmlspecialchars(substr($feedback, 0, 50)) . '...' : '-';
            error_log("Graded submission ID $submission_id: Grade=$grade, Feedback='$feedback'");
        } else {
            $response['message'] = "Erreur lors de l'enregistrement.";
            error_log("Failed to update grade for submission ID $submission_id: " . $db->error);
        }
    }

    // Output JSON for AJAX
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

$submissions = $db->query("
    SELECT qs.id, qs.quiz_id, qs.student_id, qs.response_path, qs.grade, qs.feedback, qs.submitted_at,
           q.title AS quiz_title, q.start_datetime, q.duration_hours,
           s.full_name AS student_name
    FROM quiz_submissions qs
    JOIN quizzes q ON qs.quiz_id = q.id
    JOIN students s ON qs.student_id = s.id
    ORDER BY qs.submitted_at DESC
");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Noter les Examens - Zouhair E-Learning</title>
    <link rel="icon" type="image/png" href="../assets/img/logo.png">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <style>
        .submission-on-time {
            background-color: #e6ffe6;
        }
        .submission-late {
            background-color: #ffe6e6;
        }
        .status-on-time {
            color: #28a745;
        }
        .status-late {
            color: #dc3545;
        }
        .error-message {
            color: #dc3545;
            margin-bottom: 10px;
            display: none;
        }
        .success-message {
            color: #28a745;
            margin-bottom: 10px;
            display: none;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <main class="dashboard">
        <h1><i class="fas fa-pen"></i> Noter les Examens</h1>
        <div id="form-messages">
            <p class="success-message"></p>
            <p class="error-message"></p>
        </div>
        <table id="submissionsTable" class="course-table">
            <thead>
                <tr>
                    <th>Étudiant</th>
                    <th>Examen</th>
                    <th>Date de Soumission</th>
                    <th>Statut</th>
                    <th>Note</th>
                    <th>Commentaires</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($submission = $submissions->fetch_assoc()): ?>
                    <?php
                    try {
                        $start_datetime = new DateTime($submission['start_datetime'], new DateTimeZone('Africa/Casablanca'));
                        $deadline = clone $start_datetime;
                        $duration_seconds = $submission['duration_hours'] * 3600;
                        $deadline->modify("+{$duration_seconds} seconds");
                        $submitted_at = new DateTime($submission['submitted_at'], new DateTimeZone('Africa/Casablanca'));
                        $is_on_time = $submitted_at <= $deadline;
                        $row_class = $is_on_time ? 'submission-on-time' : 'submission-late';
                        $status_text = $is_on_time ? 'À temps' : 'En retard';
                        $status_icon = $is_on_time ? '<i class="fas fa-check-circle status-on-time" title="Soumis à temps"></i> À temps' : '<i class="fas fa-times-circle status-late" title="Soumis en retard"></i> En retard';
                        error_log("Quiz: {$submission['quiz_title']}, Student: {$submission['student_name']}, " .
                            "Submitted: {$submitted_at->format('Y-m-d H:i:s')}, " .
                            "Start: {$start_datetime->format('Y-m-d H:i:s')}, " .
                            "Duration: {$submission['duration_hours']} hours, " .
                            "Deadline: {$deadline->format('Y-m-d H:i:s')}, " .
                            "On-time: " . ($is_on_time ? 'Yes' : 'No'));
                    } catch (Exception $e) {
                        error_log("Error processing submission ID {$submission['id']}: {$e->getMessage()}");
                        $row_class = 'submission-late';
                        $status_text = 'Erreur';
                        $status_icon = '<i class="fas fa-times-circle status-late" title="Erreur de calcul"></i> Erreur';
                    }
                    ?>
                    <tr class="<?php echo $row_class; ?>" data-status="<?php echo $status_text; ?>">
                        <td><?php echo htmlspecialchars($submission['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($submission['quiz_title']); ?></td>
                        <td><?php echo htmlspecialchars($submitted_at->format('Y-m-d H:i:s')); ?></td>
                        <td data-status="<?php echo $status_text; ?>"><?php echo $status_icon; ?></td>
                        <td>
                            <?php echo $submission['grade'] !== null ? number_format($submission['grade'], 2) . '/20' : '<span class="badge pending">En attente</span>'; ?>
                        </td>
                        <td><?php echo $submission['feedback'] ? htmlspecialchars(substr($submission['feedback'], 0, 50)) . '...' : '-'; ?></td>
                        <td>
                            <a href="../includes/serve_quiz_pdf.php?submission_id=<?php echo $submission['id']; ?>" class="btn-action view" title="Voir Réponse"><i class="fas fa-eye"></i></a>
                            <button class="btn-action edit grade-modal-trigger" data-submission-id="<?php echo $submission['id']; ?>" data-grade="<?php echo $submission['grade'] !== null ? number_format($submission['grade'], 2) : ''; ?>" data-feedback="<?php echo htmlspecialchars($submission['feedback'] ?? ''); ?>" title="Noter"><i class="fas fa-pen"></i></button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div id="gradeModal" class="modal">
            <div class="modal-content">
                <span class="modal-close">×</span>
                <h2><i class="fas fa-pen"></i> Noter la Soumission</h2>
                <div class="modal-messages">
                    <p class="error-message"></p>
                </div>
                <form id="gradeForm">
                    <input type="hidden" name="submission_id" id="modal_submission_id">
                    <div class="form-group">
                        <label for="grade"><i class="fas fa-star"></i> Note (0-20)</label>
                        <input type="number" name="grade" id="grade" class="course-input" step="0.01" min="0" max="20" required>
                    </div>
                    <div class="form-group">
                        <label for="feedback"><i class="fas fa-comment"></i> Commentaires</label>
                        <textarea name="feedback" id="feedback" class="course-textarea"></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="save-course-btn"><i class="fas fa-save"></i> Enregistrer</button>
                        <button type="button" class="btn-action cancel modal-close"><i class="fas fa-times"></i> Annuler</button>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <?php include '../includes/footer.php'; ?>
    <script>
        $(document).ready(function() {
            const table = $('#submissionsTable').DataTable({
                pageLength: 10,
                lengthChange: false,
                language: { url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/fr-FR.json' },
                columnDefs: [
                    {
                        targets: 3, // Status column
                        searchable: true,
                        orderable: true,
                        render: function(data, type, row, meta) {
                            if (type === 'sort' || type === 'filter') {
                                // Use data-status attribute for sorting/filtering
                                return $(row).data('status') || 'Unknown';
                            }
                            return data; // Display the HTML (icon + text)
                        }
                    },
                    {
                        targets: 2, // Date de Soumission column
                        render: function(data, type, row) {
                            if (type === 'sort') {
                                return new Date(data).getTime();
                            }
                            return data;
                        }
                    }
                ],
                order: [[2, 'desc']] // Sort by submission date descending
            });

            // Open grading modal
            $('#submissionsTable').on('click', '.grade-modal-trigger', function() {
                const submissionId = $(this).data('submission-id');
                const grade = $(this).data('grade');
                const feedback = $(this).data('feedback');
                $('#modal_submission_id').val(submissionId);
                $('#grade').val(grade);
                $('#feedback').val(feedback);
                $('.modal-messages .error-message').hide().text('');
                $('#gradeModal').show();
            });

            // Close modal
            $('.modal-close').on('click', function() {
                $('#gradeModal').hide();
                $('#gradeForm')[0].reset();
                $('#modal_submission_id').val('');
                $('.modal-messages .error-message').hide().text('');
            });

            // Close modal on outside click
            $(window).on('click', function(event) {
                if (event.target.id === 'gradeModal') {
                    $('#gradeModal').hide();
                    $('#gradeForm')[0].reset();
                    $('#modal_submission_id').val('');
                    $('.modal-messages .error-message').hide().text('');
                }
            });

            // Handle form submission via AJAX
            $('#gradeForm').on('submit', function(e) {
                e.preventDefault();
                const formData = $(this).serialize();
                const submissionId = $('#modal_submission_id').val();
                const gradeInput = $('#grade').val();
                const row = table.row($(`tr:has(button[data-submission-id="${submissionId}"])`));

                // Client-side validation
                if (gradeInput < 0 || gradeInput > 20 || isNaN(gradeInput)) {
                    $('.modal-messages .error-message').text('La note doit être entre 0 et 20.').show();
                    return;
                }

                $.ajax({
                    url: 'grade_quizzes.php',
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            // Update specific cells in the DataTable
                            table.cell(row, 4).data(response.grade).draw(false); // Update Note column
                            table.cell(row, 5).data(response.feedback).draw(false); // Update Commentaires column

                            // Log row data for debugging
                            console.log('Updated row data:', table.row(row).data());

                            // Show success message
                            $('#form-messages .success-message').text(response.message).show().delay(3000).fadeOut();
                            $('#gradeModal').hide();
                            $('#gradeForm')[0].reset();
                            $('#modal_submission_id').val('');
                            $('.modal-messages .error-message').hide().text('');

                            // Update button data attributes
                            const button = $(`button[data-submission-id="${submissionId}"]`);
                            button.data('grade', response.grade.replace('/20', ''));
                            button.data('feedback', response.feedback === '-' ? '' : response.feedback);
                        } else {
                            $('.modal-messages .error-message').text(response.message).show();
                        }
                    },
                    error: function(xhr, status, error) {
                        $('.modal-messages .error-message').text('Erreur serveur. Veuillez réessayer.').show();
                        console.error('AJAX error:', status, error);
                    }
                });
            });
        });
    </script>
</body>
</html>