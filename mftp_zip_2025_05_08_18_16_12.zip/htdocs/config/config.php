<?php
// Database credentials
define('DB_HOST', 'sql302.infinityfree.com'); // Localhost
define('DB_USER', 'if0_38743154');       // Default XAMPP MySQL user
define('DB_PASS', 'Hes0yam2002');           // Default XAMPP has no password; change if yours is different
define('DB_NAME', 'if0_38743154_zouhair_elearning'); // Your database name

// Create connection
$db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Start session (if not already started elsewhere)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>