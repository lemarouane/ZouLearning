<?php
session_start();
require_once '../includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
    $course_id = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;
    $action = isset($_POST['action']) ? htmlspecialchars($_POST['action']) : 'Unknown action';
    $course_title = isset($_POST['course_title']) ? htmlspecialchars($_POST['course_title']) : 'Unknown course';
    
    if ($user_id && $course_id) {
        $details = "$action on course: $course_title";
        $stmt = $db->prepare("INSERT INTO activity_logs (user_id, user_type, action, details) VALUES (?, 'student', 'Unauthorized action', ?)");
        $stmt->bind_param("is", $user_id, $details);
        $stmt->execute();
        echo json_encode(['status' => 'success']);
    } else {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
    }
}
?>